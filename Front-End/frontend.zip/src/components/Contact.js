import React from 'react'
export default function Contact(){
    return(
        <div>
            This is for Contact function.
        </div>
    )
}